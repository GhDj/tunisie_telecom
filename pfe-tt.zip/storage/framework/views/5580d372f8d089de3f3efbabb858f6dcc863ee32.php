<?php
/**
 * Created by PhpStorm.
 * User: ghdj
 * Date: 30/09/16
 * Time: 00:50
 */
?>



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Les Clients</div>
                    <div class="panel-body">

    <form action="<?php echo e(route('client.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="cin">
                CIN
            </label>
            <input type="number" name="cin" class="form-control">
        </div>
        <div class="gorm-group">
            <label for="nom">
                Nom
            </label>
            <input type="text" name="nom" class="form-control">
        </div>
        <div class="form-group">
            <label for="prenom">
                Prenom
            </label>
            <input type="text" name="prenom" class="form-control">
        </div>
        <div class="form-group">
            <label for="adresse">
                Adresse
            </label>
            <input type="text" name="adresse" class="form-control">
        </div>
        <div class="form-group">
            <label for="tel">
                Téléphone
            </label>
            <input type="number" name="tel" class="form-control">
        </div>
        <div class="form-group">
            <input type="submit" value="Ajouter" class="btn btn-primary">
        </div>

    </form>

<table class="table table-responsive table-striped">

<tr>
    <th>ID</th>
    <th>CIN</th>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Adresse</th>
    <th>Téléphone</th>

</tr>

<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
        <td><?php echo e($client->id); ?></td>
        <td><?php echo e($client->cin); ?></td>
        <td><?php echo e($client->nom); ?></td>
        <td><?php echo e($client->prenom); ?></td>
        <td><?php echo e($client->adresse); ?></td>
        <td><?php echo e($client->tel); ?></td>
    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>

<?php echo e($clients->links()); ?>


                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>